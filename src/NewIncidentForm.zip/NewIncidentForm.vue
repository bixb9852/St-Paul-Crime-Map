<script>
import $ from 'jquery'

export default {
    data() {
        return {
            filtered: {
                case_number: '',
                date: '',
                time: '',
                code: '',
                incident: '',
                police_grid: '',
                neighborhood_number: '',
                block: ''
            },
        }
    },
    methods: {
        caseChange: (comp) => {
            comp.filtered.case = document.getElementById('caseInput').value;
        },
        dateChange: (comp) => {
            comp.filtered.date = document.getElementById('dateInput').value;
        },
        timeChange: (comp) => {
            comp.filtered.time = document.getElementById('timeInput').value;
        },
        codeChange: (comp) => {
            comp.filtered.code = document.getElementById('codeInput').value;
        },
        incidentChange: (comp) => {
            comp.filtered.endTime = document.getElementById('endTimeInput').value;
        },
        policeChange: (comp) => {
            comp.filtered.police_grid = document.getElementById('policeInput').value;
        },
        neighborhoodChange: (comp) => {
            comp.filtered.neighborhood_number = document.getElementById('neighborhoodInput').value;
        },
        blockChange: (comp) => {
            comp.filtered.block = document.getElementById('blockInput').value;
        }

    },
    mounted() {

    }
}

</script>

<template>
    <form>
        <div class="grid-container">
            <div class="grid-y grid-padding-y">

                <!-- Date/Time/Limit Filters -->
                <div class="grid-x grid-padding-x">
                    <div class="cell small-4">
                        <h5><b>Case Information</b></h5>
                    </div>
                    <div class="cell small-4">
                        <h5><b>Date</b></h5>

                    </div>
                    <div class="cell small-4">
                        <h5><b>Incident Information</b></h5>

                    </div>
                </div>
                <div class="grid-x grid-padding-x">
                    <div class="cell small-4">
                        <div class="input-group">
                            <span class="input-group-label">Case Number</span>
                            <input id="caseInput" class="input-group-field" type="case" @change="caseChange(this)" />
                        </div>
                        <div class="input-group">
                            <span class="input-group-label">Code Number</span>
                            <input id="codeInput" class="input-group-field" type="code" @change="codeChange(this)" />
                        </div>
                    </div>
                    <div class="cell small-4">
                        <div class="input-group">
                            <span class="input-group-label">Date</span>
                            <input id="dateInput" class="input-group-field" type="date" @change="dateChange(this)" />
                        </div>
                        <div class="input-group">
                            <span class="input-group-label">Time</span>
                            <input id="timeInput" class="input-group-field" type="time" @change="timeChange(this)" />
                        </div>
                    </div>
                    <div class="cell small-4">
                        <div class="input-group">
                            <span class="input-group-label">Incident</span>
                            <input id="incidentInput" class="input-group-field" type="incident" @change="incidentChange(this)" />
                        </div>
                        <div class="input-group">
                            <span class="input-group-label">Police Grid</span>
                            <input id="policeInput" class="input-group-field" type="police_grid" @change="policeChange(this)" />
                        </div>
                        <div class="input-group">
                            <span class="input-group-label">Neighborhood Number</span>
                            <input id="neighborhoodInput" class="input-group-field" type="neighborhood_number" @change="neighborhoodChange(this)" />
                        </div>
                        <div class="input-group">
                            <span class="input-group-label">Block</span>
                            <input id="blockInput" class="input-group-field" type="block" @change="blockChange(this)" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>